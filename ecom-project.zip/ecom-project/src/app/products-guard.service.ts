import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { Observable } from 'rxjs';
import { ChooseProductService } from './choose-product/choose-product.service';

@Injectable({
  providedIn: 'root'
})
export class ProductsGuardService implements Resolve < any > {

  constructor(private chooseProductService: ChooseProductService) {}
  resolve(): Observable < any > {
   return this.chooseProductService.getProductDetails()
  }
}