import { Component, OnInit } from '@angular/core';
import { ChooseProductService } from '../choose-product/choose-product.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.scss']
})
export class ProductDetailsComponent implements OnInit {
  selectedProductData
  constructor( private productDetails: ChooseProductService) { }

  ngOnInit() {
    this.selectedProductData = this.productDetails.getSelectedProductData()
  }
  proceedToCheckout(data) {
    alert("the selected product is " +data.name)
  }

}
