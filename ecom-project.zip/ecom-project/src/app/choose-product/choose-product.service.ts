import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';


@Injectable({
  providedIn: 'root'
})
export class ChooseProductService {
  productUrl = 'assets/getAllProducts.json';
  selectedProductData
  constructor(private http: HttpClient,
    private _router: Router) { }

  setSelectedProductDetails(productData) {
    this.selectedProductData = productData
  }
  getSelectedProductData() {
    return this.selectedProductData
  }
  getProductDetails() {
    return this.http.get(this.productUrl);
  }
  getSelectedProductDetails(productId) {
    debugger
    const selectedProductUrl = `assets/${productId}/getSelectedProductDetails.json`;
    this.http.get(selectedProductUrl).subscribe(productResponse => {
      if(productResponse) {
        this.setSelectedProductDetails(productResponse);
        this._router.navigate(['/products/productDetails']);
      }
     })
    //here, we can use post(). but, as we are fetcing locally i am using get()
    //note: api is configured only for first product
  }
}
