import { TestBed } from '@angular/core/testing';

import { ChooseProductService } from './choose-product.service';

describe('ChooseProductService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ChooseProductService = TestBed.get(ChooseProductService);
    expect(service).toBeTruthy();
  });
});
