import { Component, OnInit } from '@angular/core';
import { ChooseProductService } from './choose-product.service';
import { ActivatedRoute } from '@angular/router';
import { Router, NavigationExtras } from '@angular/router';

@Component({
  selector: 'app-choose-product',
  templateUrl: './choose-product.component.html',
  styleUrls: ['./choose-product.component.scss']
})
export class ChooseProductComponent implements OnInit {
  productList
  totalRatings = [1,2,3,4,5]
  constructor (private chooseProductService: ChooseProductService,
              private routeVal: ActivatedRoute,
              private _router: Router) {
    this.productList = this.routeVal.snapshot.data['productList']
   }
   selectedProductDetails(productId) {
     if(productId > 1) {
       alert("please select first product. as the api is configured only for first prouct");
       // apis are not configured for rest of the product
     }
     this.chooseProductService.getSelectedProductDetails(productId)
   }
  ngOnInit() {}
}
