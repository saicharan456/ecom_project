import { NgModule } from '@angular/core';
import { ModuleWithProviders } from "@angular/core";
import { RouterModule, Routes } from '@angular/router';
import { ChooseProductComponent } from './choose-product/choose-product.component';
import { ProductsGuardService } from './products-guard.service';
import { ProductDetailsComponent } from './product-details/product-details.component';



const appRoutes: Routes = [
  { 
    path :'products',
    resolve: {
      productList: ProductsGuardService
     },
    component : ChooseProductComponent
  },
  {
    path : 'products/productDetails',
    component: ProductDetailsComponent
  },
  { 
    path: '', 
    redirectTo: '/products', 
    pathMatch: 'full' 
  },
  { 
    path: '**', 
    redirectTo: '/products',
    pathMatch: 'full' 
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(
      appRoutes
    )
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule {}